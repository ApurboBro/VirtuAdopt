import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Home extends JFrame {

    private Container c;
    private ImageIcon icon, logo, hlogo;
    private JLabel label1, imgLabel;
    private Font f1, f2, f3;
    private JButton btn1, btn3, btn4, btn5, btn6, btn7, btn8, nBtn;
    private Cursor cursor;

    Home() {
        
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("VirtuAdopt");
        this.setSize(1200, 600);
        this.setLocationRelativeTo(null);
        this.setResizable(false);

        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.decode("#AFF2DD"));

    
        icon = new ImageIcon(getClass().getResource("/images/ICON.jpg"));
        this.setIconImage(icon.getImage());


        logo = new ImageIcon(getClass().getResource("/images/Adopt.png"));
        imgLabel = new JLabel(logo);
        imgLabel.setBounds(690, 150, logo.getIconWidth(), logo.getIconHeight());
        c.add(imgLabel);
		
		
		hlogo = new ImageIcon(getClass().getResource("/images/Adopt.png"));
        imgLabel = new JLabel(hlogo);
        imgLabel.setBounds(690, 150, hlogo.getIconWidth(), hlogo.getIconHeight());
        c.add(imgLabel);
		

        
        f1 = new Font("Tahoma", Font.BOLD, 18);
		f3 = new Font("Segoe UI", Font.BOLD, 20);

    
        label1 = new JLabel();
        label1.setText("The most important thing you can do for an animal is to love it.");
        label1.setBounds(70, 130, 700, 90);
        label1.setFont(f3);
        c.add(label1);

        label1 = new JLabel();
        label1.setText("- Michael Franti ");
        label1.setBounds(70, 180, 600, 80);
        label1.setFont(f1);
        c.add(label1);
		
		
        cursor = new Cursor(Cursor.HAND_CURSOR);


        btn1 = new JButton("HOME");
        btn1.setBounds(140, 10, 100, 30);
        btn1.setFont(f2);
        btn1.setCursor(cursor);
        btn1.setForeground(Color.WHITE);
        btn1.setBackground(Color.decode("#C00000"));
        c.add(btn1);

        btn3 = new JButton("Choose your partner");
        btn3.setBounds(250, 10, 180, 30);
        btn3.setFont(f2);
        btn3.setCursor(cursor);
        btn3.setForeground(Color.WHITE);
        btn3.setBackground(Color.decode("#C00000"));
        c.add(btn3);

        btn4 = new JButton("Sign Up");
        btn4.setBounds(740, 10, 130, 30);
        btn4.setFont(f2);
        btn4.setCursor(cursor);
        btn4.setForeground(Color.WHITE);
        btn4.setBackground(Color.decode("#C00000"));
        c.add(btn4);
		
		
		btn5 = new JButton("Best Choices");
        btn5.setBounds(440, 10, 150, 30);
        btn5.setFont(f2);
        btn5.setCursor(cursor);
        btn5.setForeground(Color.WHITE);
        btn5.setBackground(Color.decode("#C00000"));
        c.add(btn5);
		
		
	    btn6 = new JButton("Admin Login");
        btn6.setBounds(600, 10, 130, 30);
        btn6.setFont(f2);
        btn6.setCursor(cursor);
        btn6.setForeground(Color.WHITE);
        btn6.setBackground(Color.decode("#C00000"));
        c.add(btn6);
		
		btn7 = new JButton("Log In");
        btn7.setBounds(880, 10, 130, 30);
        btn7.setFont(f2);
        btn7.setCursor(cursor);
        btn7.setForeground(Color.WHITE);
        btn7.setBackground(Color.decode("#C00000"));
        c.add(btn7);
		
		
		btn8 = new JButton("LET'S ADOPT");
        btn8.setBounds(70, 450, 230, 50);
        btn8.setFont(f2);
        btn8.setCursor(cursor);
        btn8.setForeground(Color.WHITE);
        btn8.setBackground(Color.decode("#C00000"));
        c.add(btn8);
		
        nBtn = new JButton("");
        nBtn.setBounds(0, 0, 0, 0);
        c.add(nBtn);
        
        btn3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                setVisible(false);
                Pet tr = new Pet();
                tr.setVisible(true);
            }
        });
		
         btn4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                setVisible(false);
                Registration tr = new Registration();
                tr.setVisible(true);
            }
        });
		
		
		      btn5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                setVisible(false);
                Best tr = new Best();
                tr.setVisible(true);
            }
        });

        btn8.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                Pet us = new Pet();
                us.setVisible(true);
                setVisible(false);
            }
        });
		
	
		btn7.addActionListener(new ActionListener() {  
            public void actionPerformed(ActionEvent ae) {

                Login us = new Login();
                us.setVisible(true);
                setVisible(false);
            }
        });
		
		
		
			btn6.addActionListener(new ActionListener() {  
            public void actionPerformed(ActionEvent ae) {

                AdminLogin us = new AdminLogin();
                us.setVisible(true);
                setVisible(false);
            }
        });
    }

    public static void main(String[] args) {

        Home frame = new Home();
        frame.setVisible(true);
    }
}
