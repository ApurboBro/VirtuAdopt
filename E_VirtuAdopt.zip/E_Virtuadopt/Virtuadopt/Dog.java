import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Dog extends JFrame {

    private Container c;
    private ImageIcon icon, logo;
    private JLabel imgLabel;
    private Font f1;
    private JButton btn1, btn2, btn3, btn4, btn5, btn6, nBtn;
    private Cursor cursor;

    Dog() {
        
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(1200, 600);
        this.setLocationRelativeTo(null);
        this.setResizable(false);

        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.decode("#F2F2F2"));

        icon = new ImageIcon(getClass().getResource("/images/ICON.jpg"));
        this.setIconImage(icon.getImage());


    
        f1 = new Font("Segoe UI Black", Font.BOLD, 16);

    
        cursor = new Cursor(Cursor.HAND_CURSOR);
		
		
        btn1 = new JButton("BULLDOG");
        btn1.setBounds(60, 410, 200, 50);
        btn1.setFont(f1);
        btn1.setCursor(cursor);
        btn1.setForeground(Color.WHITE);
        btn1.setBackground(Color.decode("#2E75B6"));
        c.add(btn1);

        btn2 = new JButton("POODLE");
        btn2.setBounds(350, 410, 200, 50);
        btn2.setFont(f1);
        btn2.setCursor(cursor);
        btn2.setForeground(Color.WHITE);
        btn2.setBackground(Color.decode("#2E75B6"));
        c.add(btn2);

        btn3 = new JButton("AMERICAN ESKIMO");
        btn3.setBounds(650, 410, 200, 50);
        btn3.setFont(f1);
        btn3.setCursor(cursor);
        btn3.setForeground(Color.WHITE);
        btn3.setBackground(Color.decode("#2E75B6"));
        c.add(btn3);
		
		btn4 = new JButton("SIBERIAN HUSKY");
        btn4.setBounds(930, 410, 200, 50);
        btn4.setFont(f1);
        btn4.setCursor(cursor);
        btn4.setForeground(Color.WHITE);
        btn4.setBackground(Color.decode("#2E75B6"));
        c.add(btn4);
		
		
		btn5 = new JButton("X");
        btn5.setBounds(1125, 15, 50, 30);
        btn5.setFont(f1);
        btn5.setCursor(cursor);
        btn5.setForeground(Color.WHITE);
        btn5.setBackground(Color.decode("#C00000"));
        c.add(btn5);
		
		
		
		btn6 = new JButton("<");
        btn6.setBounds(80, 15, 50, 30);
        btn6.setFont(f1);
        btn5.setCursor(cursor);
        btn6.setForeground(Color.WHITE);
        btn6.setBackground(Color.decode("#C00000"));
        c.add(btn6);
        
        nBtn = new JButton("");
        nBtn.setBounds(0, 0, 0, 0);
        c.add(nBtn);

        
        btn5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                System.exit(0);
            }
        });
		
		btn1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                BullDog sl = new BullDog();
                sl.setVisible(true);
                setVisible(false);
            }
        });

    
		btn2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                Poodle sl = new Poodle();
                sl.setVisible(true);
                setVisible(false);
            }
        });
        btn3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                setVisible(false);
             AmericanEskimo frame = new AmericanEskimo();
                frame.setVisible(true);
            }
        });        

        btn4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                setVisible(false);
                SiberianHusky frame = new SiberianHusky();
                frame.setVisible(true);
            }
        });
		
		
		    btn6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                Pet sl = new Pet();
                sl.setVisible(true);
                setVisible(false);
            }
        });
		
		
	
        logo = new ImageIcon(getClass().getResource("/images/DOGBREED.png"));
        imgLabel = new JLabel(logo);
        imgLabel.setBounds(0, 0, logo.getIconWidth(), logo.getIconHeight());
        c.add(imgLabel);
    }
	
	
	

    public static void main(String[] args) {

        Dog frame = new Dog();
        frame.setVisible(true);
    }
}
