import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DogPay extends JFrame {

    private Container c;
    private ImageIcon icon;
    private JLabel label1, label3, imgLabel;
    private Font f2, f4, f5;
    private ImageIcon logo;
    private JButton btn3, btn5, btn6, nBtn;
    private Cursor cursor;
    private ButtonGroup radioButtonGroup;
    private JRadioButton pack1, pack2, pack3, pack4;
    private int selected = 0;

    DogPay() {
        
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("VirtuAdopt");
        this.setSize(1200, 600);
        this.setLocationRelativeTo(null);
        this.setResizable(false);

        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.decode("#F2F2F2"));

        
        icon = new ImageIcon(getClass().getResource("/images/ICON1.jpg"));
        this.setIconImage(icon.getImage());

        new Font("Segoe UI Black", Font.PLAIN, 30);
        f2 = new Font("Segoe UI Semibold", Font.BOLD, 25);
        new Font("Segoe UI", Font.PLAIN, 25);
        f4 = new Font("Segoe UI", Font.PLAIN, 14);
        f5 = new Font("Segoe UI Black", Font.PLAIN, 25);

    
        
        cursor = new Cursor(Cursor.HAND_CURSOR);


        label1 = new JLabel();
        label1.setText("CHOOSE YOUR DOG");
        label1.setBounds(500, 12, 600, 50);
        label1.setFont(f2);
        c.add(label1);



        
        pack1 = new JRadioButton("Select");
        pack1.setBounds(400, 120, 80, 30);
        pack1.setFont(f4);
        pack1.setBackground(Color.decode("#F2F2F2"));
        pack1.setCursor(cursor);
        c.add(pack1);

        label3 = new JLabel();
        label3.setText("* Poodle ");
        label3.setBounds(400, 150, 520, 50);
        label3.setFont(f4);
        c.add(label3);

        label3 = new JLabel();
        label3.setText("* 5000 Taka ");
        label3.setBounds(400, 180, 520, 50);
        label3.setFont(f4);
        c.add(label3);

        
        
        pack2 = new JRadioButton("Select");
        pack2.setBounds(680, 120, 80, 30);
        pack2.setFont(f4);
        pack2.setBackground(Color.decode("#F2F2F2"));
        pack2.setCursor(cursor);
        c.add(pack2);

        label3 = new JLabel();
        label3.setText("* American Eskimo");
        label3.setBounds(680, 150, 520, 50);
        label3.setFont(f4);
        c.add(label3);

        label3 = new JLabel();
        label3.setText("* 7000 Taka ");
        label3.setBounds(680, 180, 500, 50);
        label3.setFont(f4);
        c.add(label3);



        pack3 = new JRadioButton("Select");
        pack3.setBounds(960, 120, 80, 30);
        pack3.setFont(f4);
        pack3.setBackground(Color.decode("#F2F2F2"));
        pack3.setCursor(cursor);
        c.add(pack3);

        label3 = new JLabel();
        label3.setText("* Siberian Husky");
        label3.setBounds(960, 150, 500, 50);
        label3.setFont(f4);
        c.add(label3);

        label3 = new JLabel();
        label3.setText("* 8000 Taka ");
        label3.setBounds(960, 180, 500, 50);
        label3.setFont(f4);
        c.add(label3);

        

        pack4 = new JRadioButton("Select");
        pack4.setBounds(120, 120, 80, 30);
        pack4.setFont(f4);
        pack4.setBackground(Color.decode("#F2F2F2"));
        pack4.setCursor(cursor);
        c.add(pack4);

        label3 = new JLabel();
        label3.setText("* Bulldog");
        label3.setBounds(120, 150, 500, 50);
        label3.setFont(f4);
        c.add(label3);

        label3 = new JLabel();
        label3.setText("* 6000 Taka ");
        label3.setBounds(120, 180, 500, 50);
        label3.setFont(f4);
        c.add(label3);
        

        radioButtonGroup = new ButtonGroup();
        radioButtonGroup.add(pack1);
        radioButtonGroup.add(pack2);
        radioButtonGroup.add(pack3);
        radioButtonGroup.add(pack4);

        
        btn3 = new JButton("Pay");
        btn3.setBounds(480, 480, 215, 50);
        btn3.setFont(f5);
        btn3.setCursor(cursor);
        btn3.setForeground(Color.WHITE);
        btn3.setBackground(Color.decode("#2E75B6"));
        c.add(btn3);
		
		btn5 = new JButton("X");
        btn5.setBounds(1125, 15, 50, 30);
        btn5.setFont(f4);
        btn5.setCursor(cursor);
        btn5.setForeground(Color.WHITE);
        btn5.setBackground(Color.decode("#C00000"));
        c.add(btn5);
		
		
		
	    btn6 = new JButton("<");
        btn6.setBounds(80, 15, 50, 30);
        btn6.setFont(f4);
        btn5.setCursor(cursor);
        btn6.setForeground(Color.WHITE);
        btn6.setBackground(Color.decode("#C00000"));
        c.add(btn6);
		

        nBtn = new JButton("");
        nBtn.setBounds(0, 0, 0, 0);
        c.add(nBtn);

        Handler handler = new Handler();
        pack1.addActionListener(handler);
        pack2.addActionListener(handler);
        pack3.addActionListener(handler);
        pack4.addActionListener(handler);


    
        btn3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                if (selected == 0) {
                    JOptionPane.showMessageDialog(null, "You did not select any packs.", "Warning!!!",
                            JOptionPane.WARNING_MESSAGE);
                } else {
                    setVisible(false);
                    Payment frame = new Payment();
                    frame.setVisible(true);
                }
            }
			
			
			
        });
		
		
		

        btn5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                setVisible(false);
                Home h1 = new Home();
                h1.setVisible(true);
            }
        });


		

        btn6.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent ae) {

                setVisible(false);
                Dog frame = new Dog();
                frame.setVisible(true);
            }
        });
		
		
		
		
		    
        logo = new ImageIcon(getClass().getResource("/images/h.jpg"));
        imgLabel = new JLabel(logo);
        imgLabel.setBounds(0, 80, logo.getIconWidth(), logo.getIconHeight());
        c.add(imgLabel);
	
    }

    class Handler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {

            if (e.getSource() == pack1) {
                selected = 1;
            } else if (e.getSource() == pack2) {
                selected = 2;
            } else if (e.getSource() == pack3) {
                selected = 3;
            }else if (e.getSource() == pack4) {
                selected = 4;
            }
        }
    }

    public static void main(String[] args) {

        DogPay frame = new DogPay();
        frame.setVisible(true);
    }
}
